(function($) {
Drupal.behaviors.simpliste = {attach: function (context, settings) {



}}})(jQuery);