<?php

// let's add some additional js and css
// function subtheme_preprocess_page(&$vars) {

  // png transparency fix for IE5-6 
  //	drupal_add_js(drupal_get_path('theme', 'noodle') .'/jquery.pngFix.js', 'theme');
  
  // grid support
  //	drupal_add_css(drupal_get_path('theme', 'noodle') .'/grid-12.css', 'theme');	

//	$vars['styles'] = drupal_get_css();
//	$vars['scripts'] = drupal_get_js();
// }