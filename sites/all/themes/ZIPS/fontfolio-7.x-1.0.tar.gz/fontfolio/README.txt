FontFolio Drupal Theme
----------------------

FontFolio is portfolio type theme. It is clean, grid based, 2 column theme.

Original Wordpress Theme created by Marios Lublinski from http://www.dessign.net
WP description says: FontFolio Theme for WordPress is stylish, customizable,
simple, and readable. Perfect for any illustrator or graphic designer.

Drupal version by: Israel Shmueli. http://ish.co.il 
Drupal theme demonstration website:  http://fontfolio.ish.co.il

I would like the Drupal version to be used also for artists and craftpersons
portfolios. 


Multilingual support
----------------------
Easy setup for Multilingual portfolio website.
If allowed, Links to frontpages in all Enabled languages will displayed
in the end of main menu with their own styles.  


Full RTL support
----------------------
