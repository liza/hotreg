<style type="text/css">
  body { font-family: <?php print $font_family ?>; font-size: <?php print $font_size ?>em; } 
</style>
