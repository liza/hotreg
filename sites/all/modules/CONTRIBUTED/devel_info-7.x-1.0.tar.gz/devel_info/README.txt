# $Id: README.txt,v 1.3.2.3 2010/06/24 10:40:06 flanker Exp $


Module
======
Devel Info


Description
===========
This module displays useful and helpful information for the module and theme
development. It also supports to find the cause if the website doesn't work
properly.


Requirements
============
Drupal 7.x


Installation
============
1. Move this folder into your modules directory.
2. Enable it from Administer >> Modules >> Development.


Configuration
=============
Enable and configure blocks at >> Administer >> Structure >> Blocks.


Projekt page
============
http://drupal.org/project/devel_info


Author & maintainer
===================
Ralf Stamm


License
=======
GNU General Public License (GPL)
