
Important Disclaimers:

 * 443 Session is currently under development and should be considered alpha
   code.

 * If you have not properly set up a TLS certificate and tested HTTPS access
   on your site, do not attempt to install this module as it can lock you
   out of your site. As a fail-safe, I highly recommend installing the drush
   module, http://drupal.org/project/drush, as it will allow you to disable
   a module from the command shell, i.e. without needing to log in to your
   site. See the INSTALL.txt file for details.

