You can add Internet Explorer specific stylesheet 
by adding the following files:

ie6.css
ie7.css
ie8.css
ie9.css
