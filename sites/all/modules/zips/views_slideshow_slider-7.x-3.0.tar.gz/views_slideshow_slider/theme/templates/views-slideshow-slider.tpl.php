<?php // $Id$ ?>
<div id="views_slideshow_slider_slider_<?php print $variables['vss_id']; ?>" class="views_slideshow_slider"></div>
