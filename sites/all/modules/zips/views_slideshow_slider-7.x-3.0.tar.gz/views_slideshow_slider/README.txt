
Views Slideshow: Slider
================================

This mode allows the JQuery UI slider to be used as both the control
and progress indicator of the slideshow.
