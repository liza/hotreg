// $Id$

function elfinder_drupalnodeattach_callback(url) {
          parent.jQuery('input#edit-attach-url').val(url);
          alert(url);
}