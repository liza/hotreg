<div class="<?php print $variables['classes']?>">
  <?php print render($event_title) ?>

  <?php print render($event_details) ?>
  <?php print render($event_manager_form) ?>
</div>
