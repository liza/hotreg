IMCE File Path provides a status bar like path within the IMCE file 
manager. To use enable the module and the status bar area will 
appear, no configuration is necessary.
